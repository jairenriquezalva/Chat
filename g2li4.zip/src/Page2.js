import React from "react";
import Chat from './Chat'

export default function Page2() {
  return (
    <div className="Info">
      <h1>About us:</h1>
      <div>lorem asdfasdfasfasdfasdfdsfadfssadfsdfda</div>
      <div>ChatInput</div>
      <Chat/>
    </div>
  );
}
